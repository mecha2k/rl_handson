	project "vhacd"

	kind "StaticLib"
	includedirs {
		"../inc","../public",
	}
	files {
		"*.cpp",
		"*.h"
	}
