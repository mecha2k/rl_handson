#!/bin/bash
function pre_build {
    echo "Hello world (this should not be run)"
}

function run_tests {
    echo "Hello world (this should not be run)"
}

